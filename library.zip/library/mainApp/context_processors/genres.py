from django.template.context_processors import request
from mainApp.models import Genre

def genres(request):
    genres = Genre.objects.all()

    return {
        'genres': genres,
    }