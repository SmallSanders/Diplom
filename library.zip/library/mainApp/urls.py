from django.conf import settings
from django.urls import path,include
from django.conf.urls.static import static
from django.views.static import serve
from . import views

app_name = 'mainApp'
urlpatterns = [
    path('', views.home, name="main"),
    path('library/', views.genre, name="library"),
    path('about/', views.about, name="about"),
    path('genres/<str:name_genre>_<int:genre_id>/', views.genre_detail, name="genre_detail"),
    path('<str:name_book>_<int:book_id>/', views.book_detail, name="book_detail"),
    path('<str:name_book>_<int:book_id>/leave_comment', views.leave_comment, name="leave_comment"),
    path('search/', views.search_books, name="search_books"),
    path('download/(?P<path>.*)', serve,{'document_root':settings.MEDIA_ROOT}),
] + static(settings.STATIC_URL, document_root=settings.STATICFILES_DIRS) +\
              static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)